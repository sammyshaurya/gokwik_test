import { useState } from 'react';
import logo from '../googlei.webp';

function Form() {
  const [isFocused, setIsFocused] = useState(false);
  const [message, setMessage] = useState('');
  const [value, setValue] = useState('');

  const handleOnChange = (e) => {
    const newValue = e.target.value;
    setValue(newValue);
    if (!newValue.length) {
      setMessage('');
      return;
    }
    if (newValue && !isNaN(newValue[0])) {
      checkNumber(newValue);
    } else {
      checkEmail(newValue);
    }
  };
  
  const checkEmail = (value) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (emailRegex.test(value)) {
      setMessage('Email is valid');
    } else {
      setMessage('Email is invalid');
    }
  };

  const checkNumber = (value) => {
    const phoneRegex = /^\d{10}$/;
    if (phoneRegex.test(value)) {
      setMessage('Mobile Number is valid');
    } else {
      setMessage('Mobile Number is invalid');
    }
  };

  return (
    <div className='flex w-full h-screen bg-white'>
      <div className='border p-12 max-w-lg w-full'>
        <h1 className='text-4xl font-bold mb-12 text-gray-700'>Login to Dashboard</h1>
        <form className='space-y-8'>
          <div>
            <label htmlFor='email' className='block mt-6 text-md font-medium text-gray-500'>Email or Mobile Number</label>
            <input
              type='text'
              id='email'
              className={`mt-2 block w-full p-2 border-b border-gray-300 ${isFocused ? 'border' : ''} text-lg focus:outline-none focus:border-blue-500`}
              onChange={handleOnChange}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              value={value}
            />
          </div>
          <span className={`${message.includes('invalid') ? 'text-red-600' : 'text-green-600'} font-light text-sm `}>{message}</span>
          <div className='flex items-center justify-between'>
            <button type='submit' className='w-full px-6 py-3 bg-blue-500 rounded-none text-white text-lg border rounder-sm hover:bg-blue-600 focus:outline-none focus:bg-blue-600'>Login</button>
          </div>
          <div className="flex items-center mt-4">
            <div className="w-full border-t border-gray-400"></div>
            <div className="px-4 text-gray-600 font-medium">or</div>
            <div className="w-full border-t border-gray-400"></div>
          </div>
          <button type='button' className='flex items-center justify-center w-full px-6 py-3 bg-white border border-gray-300 rounded-sm text-lg mt-4 hover:border-blue-500 focus:outline-none focus:border-blue-500'>
            <img src={logo} alt="Google Logo" className="w-6 h-6 mr-4" />
            Login with Google
          </button>
        </form>
      </div>
    </div>
  );
}

export default Form;