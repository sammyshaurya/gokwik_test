import Form from './components/Form';

function App() {
  return (
    <div className='flex h-screen bg-gray-100'>
      <div className='flex justify-end w-full sm:hidden'>
        <div className="w-auto">
          <Form />
        </div>
      </div>
      
      <div className='hidden sm:flex items-end w-8/12 xl:w-7/12 md:w-1/2 h-full pb-8'>
        <h2 className='ml-5 underline'>Created by Aman Kumar</h2>
      </div>
      
      <div className='hidden sm:flex justify-end w-4/12 xl:w-5/12 md:w-1/2 h-full'>
        <div className="w-auto">
          <Form />
        </div>
      </div>
    </div>
  );
}

export default App;
