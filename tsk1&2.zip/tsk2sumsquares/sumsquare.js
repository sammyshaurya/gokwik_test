// Run file in node env
// Approach: Use a stack and copy the array, now while stack is not empty, pop elements.
// If element is an array, push the array to stack, else add the element to sum.

// Time Complexity: O(n)
// Space Complexity: O(n) for the stack which will be same otherwise if used as recursion due to recursion stack space. 

const sumSquares = (listArr) =>{
    let sum = 0;
    let stack = listArr.slice();
    while(stack.length){
        let cur = stack.pop();
        if (Array.isArray(cur)){
            stack.push(...cur);
        }
        else{
            sum += cur*cur;
        }
    }
    return sum
}

let listArr = [[[[[[[[[1]]],7,8,8]]],4,2]]];
console.log(sumSquares(listArr));