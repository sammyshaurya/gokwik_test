// Use node env to run the code

const contains = require('./contains.js');

const nestedObject = {
  data: {
    info: {
      stuff: {
        thing: {
          moreStuff: {
            magicNumber: 44,
            something: "foo2",
          },
        },
      },
      valueFind: 'Hello goKwik',
    },
  },
};

console.log(contains(nestedObject, "jsjs"));