// Approach
// Create a stack and loop over the obj.
// If cur is the value, return true
// If cur is an object, push all of its keys to the stack.
// If not found within the obj, will return false otherwise

// Time Complexity: O(n)
// Space Complexity: O(n), Since We are using a stack, and even if we do not use a stack, 
// We are still using O(n) space due to recursion stack space.

const contains = function(searchObj, findEle){
    const stack = [searchObj]
    while(stack.length){
        const cur = stack.pop()
        if (cur === findEle){
            return true
        }
        else if (typeof cur === 'object' && cur !== null) {
            for (let key in cur){
                stack.push(cur[key])
            }
        }
    }
    return false
}

module.exports = contains